package Excepciones;

public class UnidadEstaMuertaException extends RuntimeException {
}
