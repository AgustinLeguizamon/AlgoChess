package Excepciones;

public class NoSePuedeAtacarAUnaUnidadAliadaException extends RuntimeException {
}
