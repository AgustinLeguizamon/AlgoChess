package Excepciones;

public class CasilleroEstaOcupadoException extends RuntimeException {
}
