package Excepciones;

public class NoSePuedeColocarUnidadEnSectorEnemigoException extends RuntimeException {
}
