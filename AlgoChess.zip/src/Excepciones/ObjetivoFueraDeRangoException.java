package Excepciones;

public class ObjetivoFueraDeRangoException extends RuntimeException {
}
