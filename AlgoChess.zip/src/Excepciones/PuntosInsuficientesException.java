package Excepciones;

public class PuntosInsuficientesException extends RuntimeException {
}
