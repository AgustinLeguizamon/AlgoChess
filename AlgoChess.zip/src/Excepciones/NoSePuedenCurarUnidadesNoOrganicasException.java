package Excepciones;

public class NoSePuedenCurarUnidadesNoOrganicasException extends RuntimeException {
}
