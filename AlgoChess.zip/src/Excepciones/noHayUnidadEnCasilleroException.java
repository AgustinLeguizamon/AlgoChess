package Excepciones;

public class noHayUnidadEnCasilleroException extends RuntimeException {
}
