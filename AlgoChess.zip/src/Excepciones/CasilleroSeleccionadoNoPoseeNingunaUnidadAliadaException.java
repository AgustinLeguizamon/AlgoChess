package Excepciones;

public class CasilleroSeleccionadoNoPoseeNingunaUnidadAliadaException extends RuntimeException {
}
