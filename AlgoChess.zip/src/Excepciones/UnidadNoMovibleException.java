package Excepciones;

public class UnidadNoMovibleException extends RuntimeException {
}
