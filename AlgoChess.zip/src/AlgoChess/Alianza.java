package AlgoChess;

public enum Alianza {
    AZUL,
    ROJO
}
